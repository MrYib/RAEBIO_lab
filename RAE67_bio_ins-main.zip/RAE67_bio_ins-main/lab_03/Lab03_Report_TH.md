# รายงาน Lab 03: SO(2) CPG และการเดินแบบ Tripod

**ผู้จัดทำ:** ณัฐพงษ์ มาดชาย (6752500231), กลุ่ม สาธุ  
**วันที่:** 8 พฤศจิกายน 2569  
**Model:** proposed kinematic teaching model; `dt=.05 s`; duration 30 s; warmup 10 s

## Implementation และ protocol

`student_cpg.py` ทำ simultaneous SO(2) update, alternating tripod decoder และ bounded modulation จาก manual `m` ไปยัง `phi/stride_half`; grader ผ่าน 5/5 checks สมการของสอง output ใช้ `(o1,o2)` เก่าคู่เดียวกัน จากนั้น decoder กำหนดขา Tripod A=`LF,RM,LH` กับ Tripod B=`RF,LM,RH`

Gait comparison เปลี่ยนทีละตัวแปร: baseline `(alpha=1.10, phi=.20)`, fast เปลี่ยนเฉพาะ `phi=.40`, high_gain เปลี่ยนเฉพาะ `alpha=1.30` โดยคง initial condition, stride, lift และเวลาเท่ากัน

## ผล comparison

| Condition | Distance (m) | Mean speed (m/s) | Frequency (Hz) | LF duty factor | Minimum support | Max foot clearance (m) |
|---|---:|---:|---:|---:|---:|---:|
| Baseline | 2.332679 | .077756 | .625000 | .494176 | 3 | .017095 |
| Fast | 4.665317 | .155511 | 1.267123 | .500832 | 3 | .017113 |
| High gain | 2.833701 | .094457 | .544218 | .494176 | 3 | .024637 |

การเพิ่ม phi จาก .20 เป็น .40 เพิ่มความถี่จาก .625 เป็น 1.267 Hz และระยะใน model จาก 2.333 เป็น 4.665 m; duty factor เปลี่ยนเล็กน้อยและ minimum support ยังคง 3 ขา การเพิ่ม alpha เป็น 1.30 เพิ่ม clearance จาก .0171 เป็น .0246 m และ distance เป็น 2.834 m แต่ความถี่ลดเป็น .544 Hz จึงไม่ควรเรียก gain ว่าเพิ่ม cadence

## Week 04 handoff และขอบเขต

`week4_bridge.csv` บันทึก 30 s manual modulation: `m=0` ช่วง 0–10 s, `m=1` ช่วง 10–20 s, กลับ `m=0` ช่วง 20–30 s คำสั่งเปลี่ยนจาก baseline `phi=.20 rad`, `stride_half=.055 m` ไป `.40 rad`, `.065 m` แล้วกลับ baseline; CSV แสดง oscillator transient ต่อเนื่อง ไม่ใช่การกระโดดท่าของ actuator

Grader ผ่าน 5/5; raw CSV/SVG/JSON ของทั้งสาม condition และ handoff CSV/contract อยู่ใน `results/`. แบบจำลองเป็น kinematic เท่านั้น ไม่มี rigid-body/contact-force dynamics, friction, energy, actuator tracking หรือ physical robot data จึงยังสรุป dynamic stability หรือคุณภาพการเดินจริงไม่ได้ ค่าในรายงานเป็นการอ่านผลที่มีอยู่ ไม่ใช่ prediction ที่บันทึกก่อนรัน