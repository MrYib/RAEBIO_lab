import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

# ตั้งค่าธีมกราฟ
sns.set_theme(style="whitegrid")
fig, axes = plt.subplots(1, 3, figsize=(18, 6))

# -------------------------------------------------------------
# ข้อมูลจำลองสำหรับ กราฟที่ 1 และ 2 (จาก Lab 03 CPG Simulation)
# -------------------------------------------------------------
data_conditions = {
    "condition": [
        "baseline",
        "baseline",
        "fast",
        "fast",
        "high_gain",
        "high_gain",
    ],
    "mean_speed_m_s": [0.12, 0.13, 0.25, 0.24, 0.30, 0.32],
    "oscillation_frequency_hz": [1.0, 1.1, 2.0, 1.9, 2.5, 2.6],
}
df = pd.DataFrame(data_conditions)

# -------------------------------------------------------------
# กราฟที่ 1: เปรียบเทียบ mean_speed_m_s
# -------------------------------------------------------------
sns.barplot(
    data=df,
    x="condition",
    y="mean_speed_m_s",
    ax=axes[0],
    palette="Blues_d",
    errorbar="sd",
)
axes[0].set_title("1. Mean Speed Comparison", fontsize=12, fontweight="bold")
axes[0].set_xlabel("Condition", fontsize=10)
axes[0].set_ylabel("Mean Speed (m/s)", fontsize=10)

# -------------------------------------------------------------
# กราฟที่ 2: เปรียบเทียบ oscillation_frequency_hz
# -------------------------------------------------------------
sns.barplot(
    data=df,
    x="condition",
    y="oscillation_frequency_hz",
    ax=axes[1],
    palette="Greens_d",
    errorbar="sd",
)
axes[1].set_title(
    "2. Oscillation Frequency Comparison", fontsize=12, fontweight="bold"
)
axes[1].set_xlabel("Condition", fontsize=10)
axes[1].set_ylabel("Frequency (Hz)", fontsize=10)

# -------------------------------------------------------------
# ข้อมูลจำลองสำหรับ กราฟที่ 3 (Week 4: m(t) vs phi & stride)
# -------------------------------------------------------------
data_week4 = {
    "m_t": [0.1, 0.3, 0.5, 0.7, 0.9],
    "phi": [0.2, 0.5, 0.8, 1.2, 1.5],
    "stride": [0.05, 0.10, 0.18, 0.25, 0.32],
}
df_week4 = pd.DataFrame(data_week4)

# -------------------------------------------------------------
# กราฟที่ 3: Week 4 - m(t) เปลี่ยน แล้ว φ และ stride เปลี่ยนตาม
# -------------------------------------------------------------
ax3 = axes[2]
ax3_twin = ax3.twinx()

line1 = ax3.plot(
    df_week4["m_t"],
    df_week4["phi"],
    color="#1f77b4",
    marker="o",
    linewidth=2,
    label="Phi (φ)",
)
line2 = ax3_twin.plot(
    df_week4["m_t"],
    df_week4["stride"],
    color="#ff7f0e",
    marker="s",
    linewidth=2,
    linestyle="--",
    label="Stride",
)

ax3.set_title("3. Week 4: m(t) vs φ & Stride", fontsize=12, fontweight="bold")
ax3.set_xlabel("m(t)", fontsize=10)
ax3.set_ylabel("Phi (φ)", color="#1f77b4", fontsize=10)
ax3_twin.set_ylabel("Stride", color="#ff7f0e", fontsize=10)

lines = line1 + line2
labels = [l.get_label() for l in lines]
ax3.legend(lines, labels, loc="upper left")

plt.tight_layout()

# บันทึกรูปเก็บไว้ในโฟลเดอร์อัตโนมัติ (เอาไปใส่ Worksheet / Report ได้เลย)
plt.savefig("lab03_graphs_output.png", dpi=300, bbox_inches="tight")
print("บันทึกกราฟเรียบร้อยแล้วในชื่อ lab03_graphs_output.png")

plt.show()