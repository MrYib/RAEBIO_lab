# รายงาน Lab 06: Lamp Emotion and Interaction

**ผู้จัดทำ:** ณัฐพงษ์ มาดชาย (6752500231), กลุ่ม สาธุ  
**วันที่:** 8 พฤศจิกายน 2569  
**Environment:** Python 3.13.7; standard library; policy contract: baseline (ผ่าน group contract ด้วย)

## วัตถุประสงค์และ policy

แล็บนี้ออกแบบ finite state machine สำหรับ `normal`, `interested`, `happy`, `afraid`, `sleepy` โดยรับ `fault`, `near`, `clear`, `touch`, `button`, `approach`, `timeout`, `idle` กฎที่เติมใน `student_policy.py` คือ touch เข้า happy, timeout จาก interested/happy กลับ normal และ idle จาก normal เข้า sleepy; fault/near/clear และ afraid guard คงเดิม Checker เริ่มต้นรายงานไม่ผ่าน 7 transition pairs ตาม TODO และหลังแก้ผ่านครบ 40 คู่ทั้ง baseline และ group contract

Priority ใช้กับ recognized events ใน tick เดียวกัน: `fault > near > clear > touch > button > approach > timeout > idle`; near จึงชนะ touch และเข้า afraid ซึ่ง hold positive events จน clear หรือ fault ตารางและ diagram ในใบงานบันทึกกฎครบทั้ง 5×8 คู่ การเปลี่ยน state ใช้กฎคงที่ ไม่ใช่ learning เพราะไม่มี parameter/policy update จากประสบการณ์

Movement/RGB เป็น semantic course mapping: normal `(0,0,0)` rad/RGB `(60,90,140)`; interested `(.22,.18,.06)`/`(255,180,0)`; happy `(.10,.10,.18*sin(2π elapsed))`/`(40,220,80)`; afraid `(-.22,-.22,-.16)`/`(230,30,30)`; sleepy `(0,-.15,-.20)`/`(50,40,100)`. Bounds, slew และ scheduler เป็น proposed course model ไม่ใช่ calibration หรือ safety limit ของ hardware

## Paired simulation และ latency

C0 raw และ C1 guarded ใช้ policy, output mapping, safety, scheduler และ paired seeds 41–43 เหมือนกัน ต่างที่ debounce/hysteresis C0 มี state transitions 67/72/63 เทียบ C1 9/10/9 ตามลำดับ; ทั้งหมดเป็น seeded synthetic replications ไม่ใช่ physical trials

| Condition / seed | External inputs | Both onset | ≤1 s observed | No both onset | Max observed (s) | State transitions |
|---|---:|---:|---:|---:|---:|---:|
| C0 / 41 | 10 | 7 | 7 | 3 | .24 | 67 |
| C1 / 41 | 10 | 7 | 7 | 3 | .14 | 9 |
| C0 / 42 | 10 | 6 | 6 | 4 | .18 | 72 |
| C1 / 42 | 10 | 7 | 7 | 3 | .14 | 10 |
| C0 / 43 | 10 | 6 | 6 | 4 | .04 | 63 |
| C1 / 43 | 10 | 7 | 7 | 3 | .14 | 9 |

Primary denominator ที่กำหนดไว้ล่วงหน้ามี 7 inputs ต่อ run: C0 ผ่าน 19/21 และ missing 2; C1 ผ่าน 21/21 และ missing 0 ภายใน 1 s แต่ all-source both onset มี C0 19/30 และ C1 21/30 จึงต้องรายงาน misses ด้วย ไม่เลือกเฉพาะ success ใน C1 ทั้งสาม seed, `touch_conflict` เป็น policy_held และ invalid/stale ขณะ output เป็น normal เป็น no_state_change รวม 9 no-onset; C0 ยังมี filtered/preempted outcomes จาก noise เพิ่มเติม

ตัวอย่าง C1 seed 41: `button_01` source 1.00, recognized/decision/queued 1.10, actual apply และ first motion/RGB 1.14 s; source-to-both latency .14 s `touch_01` latency .10 s; `approach_01` .04 s C0/C1 latency ของ button คือ .04/.14 s, touch .04/.10 s, approach .24/.04 s แสดงต้นทุน debounce สำหรับ digital input และผลของ hysteresis ต่อ noisy distance ใน run นี้ `motion_latency_s`, `rgb_latency_s` และ `both_latency_s` วัด onset หลัง output apply ไม่ใช่เวลา FSM ตัดสินใจ

เมื่อ near กับ touch มาพร้อมกันที่ source 7.00, C1 recognized near ที่ 7.00 และ apply afraid ที่ 7.04; touch ผ่าน debounce ที่ 7.06 จึงถูก policy_held ขณะ afraid ใน C0 ที่ไม่มี debounce, near priority ชนะ touch ใน tick เดียวกัน Clear ที่ source 9.00 กลับ normal และ apply 9.04 Fault ที่ 11/12 s เกิดตอน normal อยู่แล้วจึงไม่มี output onset และต้องรายงาน no_state_change/N/A ไม่ใส่ latency เป็นศูนย์

## Replay และขอบเขตหลักฐาน

Replay ของ `inputs_r01.csv` ให้ `raw_C1_r01.csv` และ `events_C1_r01.csv` byte-for-byte ตรงกับ run ต้นฉบับ ตรวจผ่าน replay โดยไม่สุ่ม input ใหม่ การลด transitions ของ C1 เป็นผลของ noise/filter policy ใน simulator ไม่ยืนยันการลด latency หรือความเสถียรของอุปกรณ์จริง

ก่อนทดสอบ hardware ต้องสอบเทียบศูนย์ หน่วย ทิศทาง bounds และ slew ของแกน พร้อมผู้ดูแลพื้นที่และ emergency stop ที่ตรวจสอบแล้ว วัด input/source time, first physical motion ด้วย encoder/camera และ first RGB ด้วย photodiode ด้วย clock ที่สอบเทียบและรายงาน resolution/uncertainty; แล็บนี้ไม่ได้ทดสอบ hardware, torque, collision หรือความปลอดภัย

**ทำซ้ำ:** `python check_submission.py --contract baseline` และ `python check_submission.py --contract group`; `python lab06.py --policy student --condition all --repeats 3 --output-dir results/copilot_baseline`; replay ใช้ `--condition C1 --repeats 1 --replay results/copilot_baseline/inputs_r01.csv --output-dir results/copilot_replay` ทั้งสอง output มี config, raw/events CSV, report, source snapshot และ SHA-256 manifest