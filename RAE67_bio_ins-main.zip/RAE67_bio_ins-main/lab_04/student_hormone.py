"""Lab04: complete the two TODOs. Use only the Python standard library."""
import math

def receptor(h, h_min=0.0, h_max=1.0):
    """Normalize then clamp to [0,1]. Reject nonfinite values or invalid range."""
    if not all(math.isfinite(value) for value in (h, h_min, h_max)) or h_max <= h_min:
        raise ValueError("h and receptor bounds must be finite, with h_max > h_min")
    return max(0.0, min(1.0, (h - h_min) / (h_max - h_min)))

def step(h, stimulus, dt, prod, clear, bind):
    """Return dict with h,r,raw,p,c,b,fault.

    Invalid stimulus (NaN, infinity, outside [0,1]): reset to h=r=0,
    set raw=p=c=b=0 and fault=1. Valid: use OLD h and receptor(h)
    for all rates; update once, clamp h, read NEW receptor, fault=0.
    dt and rates have already been validated by the runner.
    """
    if not math.isfinite(stimulus) or not 0.0 <= stimulus <= 1.0:
        return {"h": 0.0, "r": 0.0, "raw": 0.0, "p": 0.0,
                "c": 0.0, "b": 0.0, "fault": 1}

    r_old = receptor(h)
    production = prod * stimulus
    clearance = clear * h
    binding = bind * r_old
    raw = h + dt * (production - clearance - binding)
    h_new = max(0.0, min(1.0, raw))
    return {"h": h_new, "r": receptor(h_new), "raw": raw,
            "p": production, "c": clearance, "b": binding, "fault": 0}
