# รายงาน Lab 05: Hormone → SO(2) CPG → Kinematic Walking

**ผู้จัดทำ:** ณัฐพงษ์ มาดชาย (6752500231), กลุ่ม สาธุ  
**วันที่:** 8 พฤศจิกายน 2569  
**Environment:** Python 3.13.7; proposed course model; `dt=0.05 s`; warmup CPG 10 s; trial 30 s

## วัตถุประสงค์และแบบจำลอง

การทดลองเชื่อม scheduled stimulus ผ่าน controller เป็น `R_used` และ bounded mapping ของ `phi/stride_half` ไปยัง SO(2) CPG, tripod decoder และ kinematic stance-anchor body model โดยเปรียบเทียบ B0 fixed, B1 direct, B2 hormone และ B3 binding ablation ทุก condition ใช้ stimulus เดียวกัน (`S=1` ในช่วง 10–20 s) และ warmup CPG ด้วยคำสั่งเดียวกันก่อน reset H/R, body origin, foot anchors และ log origin

สมมติฐานจากกลไกคือ B1 ควรตอบสนองต่อ stimulus ทันที ขณะที่ B2 ต้องสะสม H ก่อน จึงมี command latency มากกว่า แต่เปลี่ยนคำสั่งต่อ step น้อยกว่า B1; total variation (TV) อาจยังใกล้กัน เพราะทั้งสอง path เคลื่อนคำสั่งในช่วงใกล้เคียงกัน การคาดการณ์นี้สรุปจาก model หลังรัน ไม่ใช่การ preregister ก่อนทดลอง

สมการแหล่งอ้างอิงใช้เป็นแนวคิด ALCS/AHM และสมการ release ใน Eq. (1) ของ Ngamkajornwiwat et al. (2020), DOI `10.1109/ACCESS.2020.2992794` ส่วน hormone Euler, mapping, scheduled input และ kinematic body เป็น **proposed course model** ไม่ใช่การทำซ้ำ MNLC, hormone-to-MI recurrence หรือ terrain experiment ของบทความ ส่วน contact mini-lab ใช้ paired-product Pearson เป็น course definition ไม่อ้างว่าเป็นการทำซ้ำ Eq. (3) ตามที่พิมพ์

## Timing และผล comparison

CSV แสดง convention ว่า command/input ที่เวลา $t_k$ ใช้ H state ต้น interval แล้วบันทึก state หลัง update ที่ $t_{k+1}$. สำหรับ B2 ที่ command 10.00 s: `H_start=0`, `R_used=0`, `phi=.2000`, `H_end=.0400` ที่ state 10.05; ที่ command 10.05 ใช้ `R_used=.0400`, `phi=.2080`, และได้ `H_end=.0784` ที่ state 10.10. ที่ command 20.00 ใช้ `R_used=.9997`, `phi=.3999`, ก่อน state ลดเป็น `.9597` ที่ 20.05

B1 command latency เป็น 0 s เพราะอ่าน `S_k` โดยตรงที่ 10.00; log state latency เป็น .05 s จาก post-update sampling convention ไม่ใช่ hardware latency ส่วน B2 command latency เป็น .15 s เพราะใช้ H state ที่สะสมแล้ว

| Condition | TV phi (rad) | Max step (rad) | Command latency (s) | Recovery (s) | On frequency (Hz) | On distance (m) |
|---|---:|---:|---:|---:|---:|---:|
| B0 | 0.0000 | 0.0000 | N/A | N/A | 0.6249 | 0.7787 |
| B1 | 0.4000 | 0.2000 | 0.00 | 0.00 | 1.2684 | 1.8252 |
| B2 | 0.3998 | 0.0080 | 0.15 | 2.85 | 1.2028 | 1.7063 |
| B3 | 0.3995 | 0.0080 | 0.15 | 3.80 | 1.2258 | 1.7275 |

ผลสนับสนุนข้อคาดการณ์เรื่องการเปลี่ยน command ค่อยเป็นค่อยไป: B2 max step ของ phi เท่ากับ .0080 rad เทียบ B1 .2000 rad และ B2 เริ่มช้ากว่า .15 s เทียบ 0 s อย่างไรก็ตาม TV ของ B2=.3998 rad แทบไม่ต่างจาก B1=.4000 rad จึงไม่สนับสนุนข้อสรุปว่า hormone ลดการเปลี่ยนสะสมตลอด trial อย่างมีนัยสำคัญ B3 ฟื้นช้ากว่า B2 ใน course model นี้ (3.80 เทียบ 2.85 s) แต่ยังคงมี H production/clearance และ CPG memory

## One-factor และ fault

ใน phi-only คง `stride_half=.055 m`; ความถี่ช่วง on ของ B1/B2 เป็น 1.2684/1.2028 Hz เท่ากับ both mapping แสดงว่า cadence gap ยังคงอยู่เมื่อยก stride ออก จาก stride-only ที่คง `phi=.20 rad`, ความถี่ B1/B2 เท่ากันที่ .6249 Hz ขณะที่ on distance ต่าง .9147/.9017 m ผลนี้สอดคล้องกับบทบาทของ phi ต่อ SO(2) recurrence และ stride ต่อระยะใน model แต่ไม่พิสูจน์ causal effect บนหุ่นยนต์จริง

เมื่อป้อน NaN ที่ command 15.00 s, B2 interval บันทึก `fault=1`, `h_used=0`, `r_used=0`, `phi=.2000 rad` และ `stride_half=.0550 m` ก่อน CPG update; state 15.05 เป็น H=0 และ state 15.10 เริ่มสะสมกลับเป็น H=.0400 นี่คือ software fallback ของ simulator ไม่ใช่การรับรอง actuator limits, emergency stop หรือ hardware safety

## Contact mini-lab

| Case | Mean SI (LF) | Mean SIF | MAE | Valid rows |
|---|---:|---:|---:|---:|
| matched | 1.0000 | 0.0000 | 0.0000 | 551 |
| gain-offset | 1.0000 | 0.0000 | 0.1628 | 551 |
| mixed-delay | 1.0000 | 0.5000 | 0.2260 | 551 |
| all-inverted | -1.0000 | 0.0000 | 0.6314 | 551 |
| constant | N/A | N/A | 0.0000 | 0 |
| fault | 1.0000 | 0.0000 | 0.0000 | 501 |

Gain-offset ได้ SI=1 เพราะ Pearson ไม่เปลี่ยนภายใต้ affine transform บวก แต่ MAE=.1628 แสดงว่า absolute agreement ไม่สมบูรณ์; จึงต้องอ่าน error ร่วมด้วย เมื่อทุกขากลับเฟส SI ทุกขาเป็น -1 แต่ SIF ซึ่งเป็น population SD ระหว่างขาเท่ากับ 0 และ release ที่ CI=1 เท่ากับ .5 SIF จึงวัดความแตกต่างระหว่างขา ไม่ได้วัดว่าทุกขาถูกต้องหรือไม่ Constant มี variance เป็นศูนย์จึงรายงาน SI เป็น N/A ไม่ใช่ศูนย์ หน้าต่าง 50 samples รวม current ทำให้แถว valid แรกอยู่ที่ 2.45 s; fault ที่ sample 300 ทำให้ 50 rolling windows ตั้งแต่ 15.00 ถึง 17.45 s ใช้ไม่ได้

## ข้อจำกัดและงานต่อ

ผลทั้งหมดเป็น deterministic simulation และ repeated run ไม่ใช่ independent trials; main runner ใช้ contact จาก decoder และไม่มี force sensing, terrain, friction, slip, CoM หรือ body dynamics จึงใช้ distance เป็นหลักฐานของ paper Displacement ไม่ได้ และไม่มีข้อมูลสำหรับ paper Stability/Harmony รวมถึงพลังงานหรือความเสี่ยงล้ม ก่อนอ้างผลกับหุ่นยนต์ควรเชื่อม CPG กับ hardware ภายใต้การทดลองที่ควบคุมได้ เก็บ joint/body motion, contact force, current/energy และ fault logs ที่ timestamp ตรงกัน ทำซ้ำหลาย trial และตรวจ actuator limits กับ emergency stop แยกจาก software bounds

**ทำซ้ำ:** ใช้ `results/copilot_comparison`, `results/copilot_phi_only`, `results/copilot_stride_only`, `results/copilot_zero`, `results/copilot_one`, `results/copilot_spike`, `results/copilot_fault` และ `results/copilot_contact`; แต่ละชุดมี config, raw CSV, source snapshot และ SHA-256 manifest รายงานกราฟเปิดได้จาก `report.html` ในแต่ละ output directory