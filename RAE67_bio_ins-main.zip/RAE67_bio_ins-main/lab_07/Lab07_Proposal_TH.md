# Mini Project Proposal: AHM–SO(2) Lamp Interaction Under Input Transport Stress

**กลุ่ม:** สาธุ  
**ผู้จัดทำ:** ณัฐพงษ์ มาดชาย (6752500231)  
**วันที่:** 8 พฤศจิกายน 2569

## คำถามและแรงบันดาลใจ

คำถามวิจัยคือ เมื่อคง policy และ controller เดิม การเปลี่ยน input delivery จาก C0 แบบ ideal ไปเป็น C1 ที่มี delay/drop ทำให้ transport age, fault fallback และการตอบสนองต่อ input ที่คาดหวังเปลี่ยนหรือไม่ ในระบบที่ออกแบบให้มี Artificial Hormone Model (AHM) ควบคู่กับ SO(2) Central Pattern Generator (CPG)? สมมติฐานคือ C1 จะเพิ่ม dropped/out-of-order messages และ fault ticks และอาจทำให้ primary source input บางรายการไม่มีทั้ง motion และ RGB onset ภายใน observation window; ค่าที่วัดได้ไม่ใช้เป็นหลักฐานว่าหุ่นยนต์รู้สึกหรือว่าการตอบสนองจริงปลอดภัย

แรงบันดาลใจด้าน AHM/CPG อ้างอิง Ngamkajornwiwat et al. (2020), *Bio-Inspired Adaptive Locomotion Control System for Online Adaptation of a Walking Robot on Complex Terrains*, IEEE Access 8, 91587–91602, DOI 10.1109/ACCESS.2020.2992794 และสมการ AHM จาก Homchanthanakul et al. (2019), DOI 10.1109/IROS40897.2019.8968580 แหล่งเหล่านี้ใช้เป็นแนวคิด ไม่ได้อ้างว่าโครงงานนี้ทำซ้ำ MNLC, micro-ROS integration หรือผลทดลอง terrain ของบทความ

รูปแบบ source AHM ที่ใช้ใน Week 04 คือ $H_c(t)=\beta H_c(t-1)+H_g(t)-H_r(t)$, โดย $H_g(t)=\alpha f(S(t))$ และ $H_r(t)=\sum_i\gamma_i\,Receptor_i(t)$. Proposed course model เลือก Euler update สำหรับ hormone เดียว: $P=k_{prod}S$, $C=k_{clear}H$, $B=k_{bind}R$, $H_{k+1}=clamp(H_k+dt(P-C-B),0,1)$ และ $R=H$. ค่าและสมการที่เลือกเป็นแบบจำลองรายวิชา ไม่ใช่ parameter ที่สอบเทียบกับ hardware

SO(2) CPG จาก Week 03/Lec5 slide 18 คำนวณพร้อมกันจาก output เก่า: $a_1=\alpha(\cos\phi\,o_1+\sin\phi\,o_2)$, $a_2=\alpha(-\sin\phi\,o_1+\cos\phi\,o_2)$, $o'_1=tanh(a_1)$, $o'_2=tanh(a_2)$. ใน integration ที่เสนอ recognized interaction สร้าง stimulus ให้ H; receptor ส่งค่าไป bounded $\phi$/stride mapping; CPG สร้าง rhythmic semantic pose; FSM สร้าง emotion label; output adapter ส่ง servo/RGB commands การเปลี่ยน transport เป็น independent variable ส่วน AHM–CPG และ emotion policy ต้องคงเดิม

## Interface และ protocol

คงเจ็ด application topics และความหมายเดียวกันระหว่าง simulation กับ robot:

| Topic | Type / meaning | Publisher → subscriber |
|---|---|---|
| `/lamp/input/button` | `std_msgs/Bool` | sensor/MCU → interaction |
| `/lamp/input/touch` | `std_msgs/Bool` | sensor/MCU → interaction |
| `/lamp/input/distance` | `std_msgs/Float32`, m | range sensor/MCU → interaction |
| `/lamp/interaction` | `std_msgs/String`, event | interaction → logger |
| `/lamp/emotion` | `std_msgs/String`, state | interaction → logger |
| `/lamp/servo_command` | `std_msgs/Float32MultiArray`, rad `[tilt,extend,nod]` | controller → collector/driver |
| `/lamp/rgb_command` | `std_msgs/ColorRGBA`, normalized 0–1, alpha=1 | controller → collector/LED driver |

ทุกคู่ใช้ RELIABLE, KEEP_LAST depth 10, VOLATILE; ตรวจ type/QoS ก่อนวิเคราะห์ topic ที่ไม่มี output ห้ามแปลง `extend` เป็นเมตรหรือ rad เป็นองศาโดยไม่ระบุ linkage/calibration ค่า alpha, dt, thresholds, slew และ mappings เป็น proposed course values

| Condition | นิยาม | Repeats |
|---|---|---:|
| C0 ideal baseline | ไม่มี modeled input delay/drop | 3 |
| C1 stress | input delay choices 0/.02/.04/.06/.10/.14/.18 s, random drop .08 และ burst 12.50–12.70 s | 3 |

จับคู่ seed 41, 42, 43 ระหว่าง C0/C1; คง policy, source script, initial state, dt, mapping, QoS และ output path ให้เหมือนกัน C1 เปลี่ยน delay และ drop พร้อมกัน จึงใช้สรุปผลของ stress profile ได้ แต่แยกสาเหตุของ delay กับ drop ไม่ได้ การทดลองถัดไปต้องเพิ่ม delay-only และ drop-only แยกต่างหาก

Scenario สำหรับผู้เข้าร่วม 600 s ต่อ trial แบ่ง 0–120 s baseline/neutral, 120–240 s button, 240–360 s touch, 360–480 s approach/clear และ 480–600 s near/touch conflict กับ recovery บันทึก source IDs ทุก event; primary set ประกาศก่อนรันเป็น `button_01,touch_01,approach_01,clear_01,near_01,clear_02,button_02`, แต่เก็บ all 10 inputs รวม conflict และ fault ด้วย ผู้เข้าร่วมต้องให้ความยินยอมและหยุดได้ทุกเมื่อ; นี่เป็นแผน ยังไม่มีการทดลองกับคน

## Metrics และแผนวัด

1. **Primary both latency (s):** จาก source timestamp/ID ถึงค่าที่ช้ากว่าระหว่าง first applied motion กับ first RGB change รายงานแยก motion, RGB, both; ถ้า modality ใดไม่มี onset ภายใน 22 s ให้เป็น N/A/null และยังอยู่ใน denominator
2. **Primary missing-both (count/7):** จำนวน expected IDs ที่ไม่มีทั้งสอง onset; แจกแจง `filtered`, `policy_held`, `preempted`, `fault` และ `censored` ห้ามเติม latency เป็นศูนย์
3. **Fault tick fraction:** ticks ที่มี invalid/stale input หารจำนวน scheduled ticks พร้อม numerator/denominator; แยก shared invalid/stale probes ออกจาก transport-induced stale
4. **Transport age (s):** receipt minus publish time เฉพาะ received messages; dropped/censored/out-of-order นับแยก ไม่ใส่ใน age mean

Offline ทำ C0/C1 สาม paired seeds ด้วย `offline_lab.py`; run นี้ตรวจ FSM/transport pipeline เท่านั้น ยังไม่รวม AHM/CPG implementation ใน Lab 07 การทดสอบโครงงานฉบับเต็มต้องเพิ่ม integrated AHM–SO(2) simulation และตรวจ source, receipt, decision, command และ physical output แยกกัน ROS messages ไม่มี Header: ใส่ source ID/time ใน sidecar, log `perf_counter_ns` ของแต่ละ node, correlate host/MCU ด้วย trigger pulses ก่อน/หลัง run และรายงาน clock drift/error bound ใช้ encoder/camera วัด motion กับ photodiode วัด RGB; หากเทียบ clock ไม่ได้ให้ source-to-physical latency เป็น N/A

## ผล preflight ที่ทำแล้ว

| Condition / seed | Drop | Out-of-order | Fault ticks | Primary pass / 7 | Missing primary | Max observed latency (s) |
|---|---:|---:|---:|---:|---:|---:|
| C0 / 41 | 0 | 0 | 20 | 7 | 0 | .14 |
| C1 / 41 | 257 | 1413 | 54 | 6 | 1 | .20 |
| C0 / 42 | 0 | 0 | 20 | 7 | 0 | .14 |
| C1 / 42 | 287 | 1421 | 81 | 6 | 1 | .22 |
| C0 / 43 | 0 | 0 | 20 | 7 | 0 | .14 |
| C1 / 43 | 300 | 1393 | 56 | 7 | 0 | .18 |

C0 มี 3303/3303 messages received ทุก seed; C1 มี dropped/out-of-order และ primary miss 1 รายการใน seed 41 (`clear_02`) กับ seed 42 (`button_02`) แต่ทุก primary onset ที่วัดได้อยู่ภายใน 1 s ผลนี้ตรงกับทิศทางที่คาดสำหรับ stress profile แต่ยังสรุปผลของ delay หรือ drop แยกกันไม่ได้ Fault ticks ของ C0=20 มาจาก invalid/stale probes ที่มีร่วมกัน ไม่ใช่ transport drop; C1 เพิ่ม fault ticks ภายใต้ profile รวม ไม่มี physical response หรือ ROS/DDS benchmark ในผลนี้

## ROS 2 Jazzy smoke run

Ubuntu 24.04.5/ROS 2 Jazzy ใช้ `colcon build --symlink-install --packages-select lamp_week07` ผ่านแล้วใน WSL. เปิด `output_collector`, `interaction` และ `synthetic_inputs` เป็นสาม process แยก ใช้ seed 41 และเก็บ sidecar traces ที่ `results/copilot_ros_run02/`; input publishers บันทึก 1101 rows ต่อ topic (3303 รวม) และ interaction/collector แสดงข้อมูลของ output ทั้งสี่ topics

ตรวจ payload ที่บันทึกแล้วพบ semantic servo arrays มีสามค่า finite ภายในช่วงที่ใช้ใน run และ RGB payload ผ่าน normalized 0..1/alpha=1 checks. อย่างไรก็ตาม interaction log มี input receives 1082 button, 1081 touch และ 1081 distance เทียบ published 1101 ต่อ topic; collector ได้ 3421 records/topic เทียบ interaction publishes 3424. สาเหตุยังระบุไม่ได้จาก sidecars เพราะ Bool/Float32 ไม่มี source sequence บน wire และบาง output อาจยังอยู่ใน flight ตอนหยุด process จึงห้ามสรุปว่า reliable delivery ครบหรืออ้าง source-to-physical latency; ต้องเพิ่ม source-correlated logging และ controlled drain/shutdown ต่อ

นี่เป็น bridge smoke run ใน ROS 2 บน WSL ไม่ใช่ timing benchmark, hardware test หรือ integrated AHM–CPG run. แก้ trace serialization ให้ `Float32MultiArray.data` แปลงเป็น list ก่อน JSON บันทึก; build และ runtime ผ่านหลังแก้ ส่วน motor driver, ESP32 firmware และ micro-ROS Agent ยังไม่มีใน package

## Real-robot plan, safety และ timeline

แผนจริงต้องใช้ Ubuntu 24.04/ROS 2 Jazzy และหุ่นยนต์ที่มี driver/MCU; Lab 07 ไม่มี motor driver, ESP32 firmware หรือ micro-ROS Agent และไม่ได้รันบน Windows session นี้ เริ่มจาก output collector กับ actuators disconnected; ต่อ sensor/interaction/driver บนโต๊ะที่ยึดมั่นคง คาลิเบรต neutral, units, direction, bounds และ slew โดยผู้สอน ตรวจ watchdog และ independent emergency stop ก่อนเปิด actuator จำกัดพื้นที่/ความเร็วและไม่ inject drop ที่ actuator command path ให้ neutral fallback เมื่อ input stale; หยุดทันทีเมื่อเกิด motion ผิดทิศ, bound violation, loss of communication, collision risk หรือผู้เข้าร่วมขอหยุด

กำหนดขั้นต่ำ 3 paired repeats ต่อ condition ทั้ง simulation และ robot; real-robot pilot เสนอผู้ใหญ่ 3 คนที่ยินยอม โดย counterbalance order C0→C1, C1→C0, C0→C1 และพักระหว่าง 600 s trials ห้ามระบุตัวตนใน log **Timeline:** 8 พ.ย. 2569 ทำ policy/proposal และ offline preflight; ระยะถัดไปติดตั้ง ROS Jazzy และ integrated simulation; จากนั้น bench calibration/stop test; ขออนุมัติการทดลองและเก็บ paired trials; ปิดท้ายตรวจ clock uncertainty, missing, replay และรายงาน วันทดลองจริงยังรอกำหนด hardware/ผู้สอน

**ทำซ้ำ:** `python check_submission.py --contract group`; `python check_proposal.py proposal.json`; `python offline_lab.py --condition all --repeats 3 --output-dir results/copilot_offline`. Replay จาก `C1_r02/input_trace.csv` ไป `results/copilot_replay` แล้ว; `input_trace.csv`, `command_trace.csv` และ `events.csv` ตรงกับ seed 42 ต้นฉบับแบบ byte-for-byte. ROS smoke-run traces อยู่ใน `results/copilot_ros_run02/`; build ผ่าน แต่มี receive-count discrepancy ที่ยังต้องวิเคราะห์. Offline/ROS outputs อยู่ในโฟลเดอร์ที่ระบุ; proposal checker ตรวจความครบของ fields แต่ผู้สอนยังต้องทบทวนความถูกต้องทางวิทยาศาสตร์และความเหมาะสมของแผนคน/หุ่นยนต์