# Lab 07 ROS 2 Jazzy Smoke Run

**วันที่:** 8 พฤศจิกายน 2569  
**ผู้จัดทำ:** ณัฐพงษ์ มาดชาย (6752500231), กลุ่ม สาธุ  
**Environment:** Ubuntu 24.04.5 LTS on WSL 2; ROS 2 Jazzy; Python 3.12.3; seed 41  
**Workspace:** `/home/windows/ros2_ws`

## Build and launch

`lamp_week07` built successfully with `colcon build --symlink-install --packages-select lamp_week07`. The package exposed `interaction`, `output_collector`, and `synthetic_inputs`. The processes were started separately in the documented order: collector, interaction with the completed Lab 07 policy, then the 22-second synthetic input schedule.

One runtime defect surfaced: `Float32MultiArray.data` is an array-backed value and is not JSON serializable directly. `ros_nodes.py` now converts it to a list for sidecar logging. Python syntax check and a fresh colcon build passed; the second run completed without the prior interaction-node exception.

## Observed traces

Raw sidecars are in `results/copilot_ros_run02/`.

| Trace | Records | Observation |
|---|---:|---|
| `inputs.csv` | 3,303 | 1,101 publish rows for each of button, touch, and distance |
| `interaction.csv` | 16,940 | 3,424 publishes on each of four output topics; input receives: button 1,082, touch 1,081, distance 1,081 |
| `collector.csv` | 13,684 | 3,421 receives on each of four output topics |

The interaction log observed all five emotion states and recognized button, touch, approach, near, clear, timeout, idle and fault events. Logged servo payloads had three finite values and observed extrema of approximately -0.22 to +0.22 rad; servo/RGB payload checks reported no invalid values.

## Limits and follow-up

There is a receive-count discrepancy: 19–20 fewer input receives per topic than input publishes, and three fewer collector receives per output topic than interaction publishes. The run does not identify whether missing callbacks are due to startup/shutdown timing, processing backlog or another transport/runtime condition. The seven wire messages do not carry source IDs/sequence headers, so exact source-to-receive matching is unavailable. Investigate with source-correlated sidecars, explicit graph/QoS checks while nodes are active, and controlled drain/shutdown before claiming delivery completeness.

This verifies ROS package build and a three-process bridge smoke run in WSL only. It is not a DDS performance benchmark, not an integrated AHM–CPG trial, and not a physical motion/RGB latency or safety test. The package still has no motor driver, ESP32 firmware or micro-ROS Agent.