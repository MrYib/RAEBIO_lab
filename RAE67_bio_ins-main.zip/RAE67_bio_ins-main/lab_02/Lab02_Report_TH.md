# รายงาน Lab 02: Robust Reactive Lamp

**ผู้จัดทำ:** ณัฐพงษ์ มาดชาย (6752500231), กลุ่ม สาธุ  
**วันที่:** 8 พฤศจิกายน 2569  
**Controller:** `student_controller.py`; student comparison SHA-256 ตรงกับ run config; C0–C3 อย่างละ 5 trials

## คำถามและวิธีทดลอง

คำถามคือรูปแบบ controller ส่งผลต่อการตอบสนองต่อ trajectory ระยะเดียวกันภายใต้ noise อย่างไร โดยใช้ C0 open-loop, C1 raw single threshold, C2 low-pass filter + hysteresis และ C3 proportional response พร้อม clamp; ทุก condition ใช้ noise sigma=.01 m และ delay=0 ms ใน comparison หลัก

การทำซ้ำได้จาก `python lab02.py --controller-source student --protocol controller-comparison --student-file student_controller.py --out results/student_comparison`. Student checker ผ่าน 10/10 checks ทั้ง filter, threshold, hysteresis, proportional/clamp, invalid sample และ full trial C0–C3

## ผล comparison

| Condition | Enter latency (s) | Exit latency (s) | False trigger/min | Extra switches | Mean |Δcommand| |
|---|---:|---:|---:|---:|---:|
| C0 | .0029 | 2.8571 | 2.9970 | 0.0 | .00120 |
| C1 | .0189 | .0291 | 8.3916 | 12.4 | .00864 |
| C2 | .4069 | .4531 | 0.0000 | 0.0 | .00120 |
| C3 | .0429 | .0891 | 1.7982 | 1.6 | .00465 |

C1 ตอบสนองเร็วแต่มี false-trigger rate และ switching มากที่สุดใน comparison นี้ C2 ลด false trigger/extra switches เป็นศูนย์ แลกกับ enter latency ประมาณ .407 s และ recovery .454 s C3 อยู่กึ่งกลาง: latency ต่ำกว่า C2 แต่มี false trigger 1.798/min และ 1.6 extra switches ค่าเหล่านี้เป็นผลตามนิยาม metric ของ simulator ไม่ใช่เกณฑ์ความปลอดภัยของหุ่นยนต์

## Noise และ delay: C2

Full robustness set มี 9 combinations × 5 trials รวม 45 trials; ทุก combination ของ C2 มี false trigger และ extra switches เป็นศูนย์ในชุดนี้ เมื่อ delay เพิ่ม 0→100→300 ms latency โดยรวมสูงขึ้น ตัวอย่าง sigma=0: recovery .4229→.5229→.7229 s; sigma=.01: .4337→.5434→.7526 s; sigma=.03: .4097→.4954→.6406 s. Invalid samples เฉลี่ยเป็น 0/5/15 ต่อ trial ตาม delay 0/100/300 ms เนื่องจาก stale-sample policy

ผลของ noise ไม่เพิ่ม latency แบบ monotonic ในทุกระดับ: ที่ delay 300 ms ค่า recovery ของ sigma=.03 (.6406 s) ต่ำกว่า sigma=.01 (.7526 s) ขณะที่ invalid counts ถูกขับโดย delay เป็นหลัก การวัดนี้สนับสนุนผลของ delay ต่อ latency/staleness แต่ไม่ควรสรุปว่า noise ทุกระดับทำให้ response ช้าลงเสมอ

## การตรวจและข้อจำกัด

`grade_submission.py` ผ่าน 10/10; `results/student_comparison/run_config.json` บันทึก `controller_source=student`, 20 trials และ hash ที่ตรงกับไฟล์ปัจจุบัน Unit tests มี 12 ข้อ โดย 10 ผ่านและ 2 ทดสอบโดยเจตนาว่า starter ที่ยังไม่เสร็จต้องโยน `NotImplementedError`; สองข้อนี้จึงไม่ผ่านเมื่อใช้ controller ที่ implement ครบ ไม่ใช่ข้อผิดพลาดใน grader

ผลยังเป็น proposed course simulation: ระยะจริงเป็น ground truth สังเคราะห์ ไม่มี sensor/actuator จริง การวัด latency/command และ safe bounds ต้องสอบเทียบใหม่ก่อนใช้ hardware ส่วน prediction ในรายงานนี้สรุปจากไฟล์ผลที่มีอยู่ ไม่ใช่ preregistration ก่อนรัน